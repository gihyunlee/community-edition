//>>built
define("dijit/form/nls/pt/validate",({invalidMessage:"O valor inserido não é válido.",missingMessage:"Este valor é necessário.",rangeMessage:"Este valor está fora do intervalo. "}));
