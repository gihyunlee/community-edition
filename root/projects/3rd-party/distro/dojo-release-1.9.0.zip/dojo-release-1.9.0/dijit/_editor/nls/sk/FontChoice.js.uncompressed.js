define(
"dijit/_editor/nls/sk/FontChoice", ({
	fontSize: "Veľkosť",
	fontName: "Písmo",
	formatBlock: "Formát",
	serif: "serif",
	"sans-serif": "sans-serif",
	monospace: "monospace",
	cursive: "cursive",
	fantasy: "fantasy",
	noFormat: "Žiadny",
	p: "Odsek",
	h1: "Hlavička",
	h2: "Podhlavička",
	h3: "Pod-podhlavička",
	pre: "Predformátované",
	1: "xx-small",
	2: "x-small",
	3: "small",
	4: "medium",
	5: "large",
	6: "x-large",
	7: "xx-large"
})
);
